# Arduino library for LPD8806 #
This Library was written for the LPD8806 PWM LED driver chips, strips and pixels.
But the LPD8803/LPD8809 will probably work too.

## Where to Buy? ##
Pick some up at [Adafruit Industries](http://www.adafruit.com/products/306)
